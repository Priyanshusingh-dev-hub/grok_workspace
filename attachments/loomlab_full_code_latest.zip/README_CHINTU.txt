LoomLab code - Chintu ke computer ka latest (18 Oct 2026)
Base: branch feat/numbering-prepress
Commits (local, not pushed): f467c7f (PSD optional COMPOSITE), e392b54 (auto mode + channels-only PSD)
Uncommitted work-in-progress included: textile/auto.py, textile/cli.py, tests/test_auto.py
  (supersampled pen-tool edges, no downscale, tiling) - NOT finished; design14 dot rings still jagged.
Modes: number (main), spray, --hybrid, auto
Run tests: cd textile_project && python -m pytest -q
